"use strict";
(globalThis["webpackChunkeinstein_frontend"] = globalThis["webpackChunkeinstein_frontend"] || []).push([["node_modules_tanstack_query-devtools_build_DevtoolsComponent_E3YREIG7_js"],{

/***/ "./node_modules/@tanstack/query-devtools/build/DevtoolsComponent/E3YREIG7.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@tanstack/query-devtools/build/DevtoolsComponent/E3YREIG7.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ DevtoolsComponent_default)
/* harmony export */ });
/* harmony import */ var _chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../chunk/NDYUDEEA.js */ "./node_modules/@tanstack/query-devtools/build/chunk/NDYUDEEA.js");
/* harmony import */ var _chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../chunk/JAD5ECXD.js */ "./node_modules/@tanstack/query-devtools/build/chunk/JAD5ECXD.js");



// src/DevtoolsComponent.tsx
var DevtoolsComponent = props => {
  const [localStore, setLocalStore] = (0,_chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.createLocalStorage)({
    prefix: "TanstackQueryDevtools"
  });
  const colorScheme = (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.getPreferredColorScheme)();
  const theme = (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.createMemo)(() => {
    const preference = localStore.theme_preference || _chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.THEME_PREFERENCE;
    if (preference !== "system") return preference;
    return colorScheme();
  });
  return (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.createComponent)(_chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.QueryDevtoolsContext.Provider, {
    value: props,
    get children() {
      return (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.createComponent)(_chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.PiPProvider, {
        localStore,
        setLocalStore,
        get children() {
          return (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.createComponent)(_chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.ThemeContext.Provider, {
            value: theme,
            get children() {
              return (0,_chunk_JAD5ECXD_js__WEBPACK_IMPORTED_MODULE_1__.createComponent)(_chunk_NDYUDEEA_js__WEBPACK_IMPORTED_MODULE_0__.Devtools, {
                localStore,
                setLocalStore
              });
            }
          });
        }
      });
    }
  });
};
var DevtoolsComponent_default = DevtoolsComponent;


/***/ })

}]);
//# sourceMappingURL=node_modules_tanstack_query-devtools_build_DevtoolsComponent_E3YREIG7_js.chunk.js.map