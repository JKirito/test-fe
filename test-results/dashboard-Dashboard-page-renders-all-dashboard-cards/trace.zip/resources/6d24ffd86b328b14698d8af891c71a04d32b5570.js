"use strict";
(globalThis["webpackChunkeinstein_frontend"] = globalThis["webpackChunkeinstein_frontend"] || []).push([["src_pages_dashboard_dashboard_tsx"],{

/***/ "./src/pages/dashboard/components/dashboard-card/dashboard-card.tsx":
/*!**************************************************************************!*\
  !*** ./src/pages/dashboard/components/dashboard-card/dashboard-card.tsx ***!
  \**************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardCard: () => (/* binding */ DashboardCard)
/* harmony export */ });
/* harmony import */ var _dashboard_card_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard-card.scss */ "./src/pages/dashboard/components/dashboard-card/dashboard-card.scss");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "D:\\coding\\agent\\einstein-fe\\src\\pages\\dashboard\\components\\dashboard-card\\dashboard-card.tsx";


function DashboardCard({
  path,
  title,
  subtitle,
  onClick
}) {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    onClick: onClick,
    className: "dashboard-card e-pd-24 e-br-24 e-crs-pointer",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("img", {
      className: "dashboard-card-icon",
      src: `/icons/${path}.svg`,
      alt: ""
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: "dashboard-card-title e-heading-6 e-700",
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: "dashboard-card-subtitle e-body-4 e-grayscale-500",
      children: subtitle
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, this);
}
_c = DashboardCard;
var _c;
__webpack_require__.$Refresh$.register(_c, "DashboardCard");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/pages/dashboard/dashboard.model.ts":
/*!************************************************!*\
  !*** ./src/pages/dashboard/dashboard.model.ts ***!
  \************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DashboardCards: () => (/* binding */ DashboardCards)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

const DashboardCards = [{
  path: 'curiosity',
  title: 'Curiosity',
  navLink: '/curiosity',
  subtitle: 'Coming Soon: AI-Powered Insights and Recommendations'
}, {
  path: 'methods',
  title: 'Methods',
  navLink: '/methodologies',
  subtitle: 'Standardised Processes, Templates & Best Practices For Your Projects & Pitches'
}, {
  path: 'maps',
  title: 'Maps',
  navLink: '/map',
  subtitle: 'Geospatial Views Of Our Projects And Their Artefacts For Your Pitches'
}, {
  path: 'galileo',
  title: 'Galileo',
  navLink: '/galileo',
  subtitle: 'Benchmarks & Analytics For Your Projects & Pitches'
}, {
  path: 'abacus-cost',
  title: 'Abacus-Cost',
  navLink: '/abacus-cost',
  subtitle: 'Benchmark & Estimate Costs For Your Projects & Pitches'
}, {
  path: 'how-to',
  title: 'How To',
  navLink: '/how-to',
  subtitle: 'Industry-Based Tool Kits From Inception To Close Out For Your Projects & Pitches'
}];

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/pages/dashboard/dashboard.tsx":
/*!*******************************************!*\
  !*** ./src/pages/dashboard/dashboard.tsx ***!
  \*******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Dashboard)
/* harmony export */ });
/* harmony import */ var _dashboard_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.scss */ "./src/pages/dashboard/dashboard.scss");
/* harmony import */ var _components_dashboard_card_dashboard_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/dashboard-card/dashboard-card */ "./src/pages/dashboard/components/dashboard-card/dashboard-card.tsx");
/* harmony import */ var _shared_background_background__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/background/background */ "./src/shared/background/background.tsx");
/* harmony import */ var _dashboard_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard.model */ "./src/pages/dashboard/dashboard.model.ts");
/* harmony import */ var react_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-router */ "./node_modules/react-router/dist/development/chunk-SYFQ2XB5.mjs");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/dist/react-redux.mjs");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "D:\\coding\\agent\\einstein-fe\\src\\pages\\dashboard\\dashboard.tsx",
  _s = __webpack_require__.$Refresh$.signature();


// import { Header } from '../../einstein/components/common/header/header';





function Dashboard() {
  _s();
  const navigate = (0,react_router__WEBPACK_IMPORTED_MODULE_5__.useNavigate)();
  const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)(state => state.auth.user);
  const handleClick = path => {
    // console.log('path', path);
    navigate(path);
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
    className: "dashboard e-pd-40 e-margin-centered",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_shared_background_background__WEBPACK_IMPORTED_MODULE_2__.Background, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "page-heading",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
        className: "page-heading__container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
          className: "page-heading__container-title e-heading-title",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("h1", {
            className: "e-heading-4 e-600 e-no-selection",
            children: ["Welcome,", ' ', /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("span", {
              className: "e-heading-4 e-600 e-brand-title e-accent-title",
              children: (user === null || user === void 0 ? void 0 : user.name.split(' ')[0]) || 'User'
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 28,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)("div", {
      className: "dashboard-cards e-mg-t-48",
      children: _dashboard_model__WEBPACK_IMPORTED_MODULE_3__.DashboardCards.map((card, index) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxDEV)(_components_dashboard_card_dashboard_card__WEBPACK_IMPORTED_MODULE_1__.DashboardCard, {
        onClick: () => handleClick(card.navLink),
        path: card.path,
        navLink: card.navLink,
        title: card.title,
        subtitle: card.subtitle
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 11
      }, this))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, this);
}
_s(Dashboard, "pweDhniV3i3CFJjuIZK4sgjH9PE=", false, function () {
  return [react_router__WEBPACK_IMPORTED_MODULE_5__.useNavigate, react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector];
});
_c = Dashboard;
var _c;
__webpack_require__.$Refresh$.register(_c, "Dashboard");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/shared/background/background.tsx":
/*!**********************************************!*\
  !*** ./src/shared/background/background.tsx ***!
  \**********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Background: () => (/* binding */ Background)
/* harmony export */ });
/* harmony import */ var _background_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./background.scss */ "./src/shared/background/background.scss");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");

var _jsxFileName = "D:\\coding\\agent\\einstein-fe\\src\\shared\\background\\background.tsx";


function Background() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "background",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("svg", {
      className: "background-svg",
      xmlns: "http://www.w3.org/2000/svg",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("defs", {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("filter", {
          id: "goo",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("feGaussianBlur", {
            in: "SourceGraphic",
            stdDeviation: "10",
            result: "blur"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 9,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("feColorMatrix", {
            in: "blur",
            mode: "matrix",
            values: "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -8",
            result: "goo"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 10,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("feBlend", {
            in: "SourceGraphic",
            in2: "goo"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 8,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 7,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 6,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
      className: "background-container",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__blob-1"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__blob-2"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__blob-3"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__blob-4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__blob-4"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
        className: "background-container__interactive"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 5
  }, this);
}
_c = Background;
var _c;
__webpack_require__.$Refresh$.register(_c, "Background");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (true) {
			errorOverlay = false;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/components/dashboard-card/dashboard-card.scss":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/components/dashboard-card/dashboard-card.scss ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.dashboard-card {
  display: flex;
  flex-direction: column;
  flex-wrap: initial;
  justify-content: initial;
  align-items: flex-start;
  gap: var(--e-sp-16);
  width: 100%;
  height: 248px;
  opacity: 0;
  transform-origin: top center;
  transition: all 200ms ease-in-out;
  animation: eRotateX 600ms ease-in-out forwards;
  box-shadow: var(--e-shadow-base);
  background-color: var(--e-grayscale-white);
}
@media (min-width: 768px) {
  .dashboard-card {
    width: calc(50% - var(--e-sp-12));
  }
}
@media (min-width: 1280px) {
  .dashboard-card {
    width: calc(33% - var(--e-sp-12));
  }
}
.dashboard-card:nth-child(1) {
  animation-delay: 1090ms;
}
.dashboard-card:nth-child(2) {
  animation-delay: 1180ms;
}
.dashboard-card:nth-child(3) {
  animation-delay: 1270ms;
}
.dashboard-card:nth-child(4) {
  animation-delay: 1360ms;
}
.dashboard-card:nth-child(5) {
  animation-delay: 1450ms;
}
.dashboard-card:nth-child(6) {
  animation-delay: 1540ms;
}
.dashboard-card:nth-child(7) {
  animation-delay: 1630ms;
}
.dashboard-card:nth-child(8) {
  animation-delay: 1720ms;
}
.dashboard-card:nth-child(9) {
  animation-delay: 1810ms;
}
.dashboard-card:nth-child(10) {
  animation-delay: 1900ms;
}
.dashboard-card:hover {
  color: var(--e-grayscale-white);
  background-color: var(--e-primary-500);
  transition: all 200ms ease-in-out;
}
.dashboard-card:hover .dashboard-card-subtitle {
  color: var(--e-grayscale-white);
  transition: all 200ms ease-in-out;
}
.dashboard-card-icon {
  display: flex;
  flex-direction: column;
  flex-wrap: initial;
  justify-content: center;
  align-items: center;
  gap: initial;
  width: 80px;
  height: 80px;
  transition: all 200ms ease-in-out;
}
.dashboard-card-subtitle {
  letter-spacing: 0.32px;
  line-height: 150%;
}
@media (min-width: 1280px) {
  .dashboard-card-subtitle {
    font-size: var(--e-body-3);
  }
}`, "",{"version":3,"sources":["webpack://./src/pages/dashboard/components/dashboard-card/dashboard-card.scss","webpack://./src/styles/utils/mixins.scss","webpack://./src/styles/utils/breakpoints.scss"],"names":[],"mappings":"AASA;ECRC,aAAA;EACA,sBDQmB;ECPnB,kBAHwF;EAIxF,wBDM2B;ECL3B,uBDKoC;ECJpC,mBDIgD;EAChD,WAAA;EACA,aAAA;EACA,UAAA;EACA,4BAAA;EACA,iCAAA;EACA,8CAAA;EACA,gCAAA;EACA,0CAAA;AAHD;AEAC;EFND;IAYE,iCAAA;EAFA;AACF;AESC;EFpBD;IAgBE,iCAAA;EADA;AACF;AAIE;EACC,uBAAA;AAFH;AACE;EACC,uBAAA;AACH;AAFE;EACC,uBAAA;AAIH;AALE;EACC,uBAAA;AAOH;AARE;EACC,uBAAA;AAUH;AAXE;EACC,uBAAA;AAaH;AAdE;EACC,uBAAA;AAgBH;AAjBE;EACC,uBAAA;AAmBH;AApBE;EACC,uBAAA;AAsBH;AAvBE;EACC,uBAAA;AAyBH;AArBC;EACC,+BAAA;EACA,sCAAA;EACA,iCAAA;AAuBF;AArBE;EACC,+BAAA;EACA,iCAAA;AAuBH;AAnBC;EC5CA,aAAA;EACA,sBD4CoB;EC3CpB,kBAHwF;EAIxF,uBD0C4B;ECzC5B,mBDyCoC;ECxCpC,YANwE;ED+CvE,WAxCsB;EAyCtB,YAzCsB;EA0CtB,iCAAA;AA0BF;AAvBC;EACC,sBAAA;EACA,iBAAA;AAyBF;AElDC;EFuBA;IAKE,0BAAA;EA0BD;AACF","sourcesContent":["\n          @use \"@/styles/utils/mixins\" as mx;\n          @use \"@/styles/utils/breakpoints\" as bp;\n        \n// @use '@/styles/utils/mixins' as mx;\r\n// @use '@/styles/utils/breakpoints' as bp;\r\n\r\n$dashboardCardIconSize: 80px;\r\n\r\n.dashboard-card {\r\n\t@include mx.e-flex(column, initial, flex-start, var(--e-sp-16));\r\n\twidth: 100%;\r\n\theight: 248px;\r\n\topacity: 0;\r\n\ttransform-origin: top center;\r\n\ttransition: all 200ms ease-in-out;\r\n\tanimation: eRotateX 600ms ease-in-out forwards;\r\n\tbox-shadow: var(--e-shadow-base);\r\n\tbackground-color: var(--e-grayscale-white);\r\n\r\n\t@include bp.s {\r\n\t\twidth: calc(50% - var(--e-sp-12));\r\n\t}\r\n\r\n\t@include bp.l {\r\n\t\twidth: calc(33% - var(--e-sp-12));\r\n\t}\r\n\r\n\t@for $i from 1 through 10 {\r\n\t\t&:nth-child(#{$i}) {\r\n\t\t\tanimation-delay: #{1000ms + $i * 90ms};\r\n\t\t}\r\n\t}\r\n\r\n\t&:hover {\r\n\t\tcolor: var(--e-grayscale-white);\r\n\t\tbackground-color: var(--e-primary-500);\r\n\t\ttransition: all 200ms ease-in-out;\r\n\r\n\t\t.dashboard-card-subtitle {\r\n\t\t\tcolor: var(--e-grayscale-white);\r\n\t\t\ttransition: all 200ms ease-in-out;\r\n\t\t}\r\n\t}\r\n\r\n\t&-icon {\r\n\t\t@include mx.e-flex(column, center, center);\r\n\t\twidth: $dashboardCardIconSize;\r\n\t\theight: $dashboardCardIconSize;\r\n\t\ttransition: all 200ms ease-in-out;\r\n\t}\r\n\r\n\t&-subtitle {\r\n\t\tletter-spacing: 0.32px;\r\n\t\tline-height: 150%;\r\n\r\n\t\t@include bp.l {\r\n\t\t\tfont-size: var(--e-body-3);\r\n\t\t}\r\n\t}\r\n}\r\n","@mixin e-flex($direction: row, $justify: initial, $align: initial, $gap: initial, $wrap: initial) {\r\n\tdisplay: flex;\r\n\tflex-direction: $direction;\r\n\tflex-wrap: $wrap;\r\n\tjustify-content: $justify;\r\n\talign-items: $align;\r\n\tgap: $gap;\r\n}\r\n\r\n@mixin e-anim-rotate-x($duartion: 300ms, $delay: 30ms) {\r\n\topacity: 0;\r\n\ttransform-origin: top center;\r\n\tanimation: eRotateX $duartion $delay ease-in-out forwards;\r\n}\r\n","// Mobile\r\n@mixin xs-mobile {\r\n\t@media (max-width: 500px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n@mixin xs {\r\n\t@media (min-width: 500px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Tablet\r\n@mixin s {\r\n\t@media (min-width: 768px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Tablet/Desktop\r\n@mixin m {\r\n\t@media (min-width: 1024px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Desktop\r\n@mixin l {\r\n\t@media (min-width: 1280px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Large Desktop\r\n@mixin xl {\r\n\t@media (min-width: 1440px) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Custom Breakpoint\r\n@mixin custom($screen) {\r\n\t@media (min-width: #{$screen}) {\r\n\t\t@content;\r\n\t}\r\n}\r\n\r\n// Print\r\n@mixin print($orientation: portrait) {\r\n\t@media print {\r\n\t\t@if $orientation==portrait {\r\n\t\t\t@page {\r\n\t\t\t\tsize: portrait;\r\n\t\t\t}\r\n\t\t} @else if $orientation==landscape {\r\n\t\t\t@page {\r\n\t\t\t\tsize: landscape;\r\n\t\t\t}\r\n\t\t} @else {\r\n\t\t\t@warn \"Invalid orientation parameter. Use 'portrait' or 'landscape'.\";\r\n\t\t}\r\n\r\n\t\t@content;\r\n\t}\r\n}\r\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/dashboard.scss":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/dashboard.scss ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `.dashboard {
  height: calc(100vh - var(--e-header) - var(--e-sp-80));
  max-width: var(--e-max-width);
  padding-top: 104px;
}
.dashboard-cards {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: initial;
  align-items: initial;
  gap: var(--e-sp-24);
}`, "",{"version":3,"sources":["webpack://./src/pages/dashboard/dashboard.scss","webpack://./src/styles/utils/mixins.scss"],"names":[],"mappings":"AAMA;EACC,sDAAA;EACA,6BAAA;EACA,kBAAA;AALD;AAOC;ECVA,aAAA;EACA,mBDUoB;ECTpB,eDS2D;ECR3D,wBDQyB;ECPzB,oBDOkC;ECNlC,mBDM2C;AAA5C","sourcesContent":["\n          @use \"@/styles/utils/mixins\" as mx;\n          @use \"@/styles/utils/breakpoints\" as bp;\n        \n// @use '@/styles/utils/mixins' as mx;\r\n\r\n.dashboard {\r\n\theight: calc(100vh - var(--e-header) - var(--e-sp-80));\r\n\tmax-width: var(--e-max-width);\r\n\tpadding-top: 104px;\r\n\r\n\t&-cards {\r\n\t\t@include mx.e-flex(row, initial, initial, var(--e-sp-24), wrap);\r\n\t}\r\n}\r\n","@mixin e-flex($direction: row, $justify: initial, $align: initial, $gap: initial, $wrap: initial) {\r\n\tdisplay: flex;\r\n\tflex-direction: $direction;\r\n\tflex-wrap: $wrap;\r\n\tjustify-content: $justify;\r\n\talign-items: $align;\r\n\tgap: $gap;\r\n}\r\n\r\n@mixin e-anim-rotate-x($duartion: 300ms, $delay: 30ms) {\r\n\topacity: 0;\r\n\ttransform-origin: top center;\r\n\tanimation: eRotateX $duartion $delay ease-in-out forwards;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/shared/background/background.scss":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/shared/background/background.scss ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `:root {
  --color1: 20, 158, 246;
  --color2: 67, 179, 251;
  --color3: 11, 118, 187;
  --color-interactive: 20, 158, 246;
  --circle-size: 80%;
  --blending: hard-light;
}

@keyframes backgroundMoveInCircle {
  0% {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
@keyframes backgroundMoveVertical {
  0% {
    transform: translateY(-50%);
  }
  50% {
    transform: translateY(50%);
  }
  100% {
    transform: translateY(-50%);
  }
}
@keyframes backgroundMoveHorizontal {
  0% {
    transform: translateX(-50%) translateY(-10%);
  }
  50% {
    transform: translateX(50%) translateY(10%);
  }
  100% {
    transform: translateX(-50%) translateY(-10%);
  }
}
.background {
  width: 100vw;
  height: 100vh;
  position: absolute;
  overflow: hidden;
  background: linear-gradient(40deg, var(var(--e-grayscale-100)), var(var(--e-grayscale-100)));
  top: 0;
  left: 0;
  z-index: -1;
  animation: eFade 800ms ease-in-out forwards;
}
.background-svg {
  position: fixed;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
}
.background-container {
  filter: url(#goo) blur(40px);
  width: 100%;
  height: 100%;
}
.background-container__blob-1, .background-container__blob-2, .background-container__blob-3, .background-container__blob-4, .background-container__blob-5 {
  position: absolute;
  mix-blend-mode: hard-light;
}
.background-container__blob-1, .background-container__blob-2 {
  width: var(--circle-size);
  height: var(--circle-size);
  top: calc(50% - var(--circle-size) / 2);
  left: calc(50% - var(--circle-size) / 2);
}
.background-container__blob-1 {
  background: radial-gradient(circle at center, rgba(var(--color1), 0.4) 0, rgba(var(--color1), 0) 50%) no-repeat;
  transform-origin: center center;
  animation: backgroundMoveVertical 30s ease infinite;
  opacity: 1;
}
.background-container__blob-2 {
  background: radial-gradient(circle at center, rgba(var(--color2), 0.4) 0, rgba(var(--color2), 0) 50%) no-repeat;
  transform-origin: calc(50% - 400px);
  animation: backgroundMoveInCircle 20s reverse infinite;
  opacity: 1;
}
.background-container__blob-3 {
  position: absolute;
  background: radial-gradient(circle at center, rgba(var(--color3), 0.4) 0, rgba(var(--color3), 0) 50%) no-repeat;
  width: var(--circle-size);
  height: var(--circle-size);
  top: calc(50% - var(--circle-size) / 2 + 200px);
  right: calc(50% - var(--circle-size) / 2 - 500px);
  transform-origin: calc(50% + 400px);
  animation: backgroundMoveInCircle 40s linear infinite;
  opacity: 1;
}
.background-container__blob-4 {
  width: var(--circle-size);
  height: var(--circle-size);
  top: calc(50% - var(--circle-size) / 2);
  right: calc(50% - var(--circle-size) / 2);
  background: radial-gradient(circle at center, rgba(var(--color4), 0.4) 0, rgba(var(--color4), 0) 50%) no-repeat;
  transform-origin: calc(50% - 200px);
  animation: backgroundMoveHorizontal 40s ease infinite;
  opacity: 0.7;
}
.background-container__blob-5 {
  background: radial-gradient(circle at center, rgba(var(--color5), 0.4) 0, rgba(var(--color5), 0) 50%) no-repeat;
  width: calc(var(--circle-size) * 2);
  height: calc(var(--circle-size) * 2);
  bottom: calc(50% - var(--circle-size));
  right: calc(50% - var(--circle-size));
  transform-origin: calc(50% - 800px) calc(50% + 200px);
  animation: backgroundMoveInCircle 20s ease infinite;
  opacity: 1;
}
.background-container__interactive {
  background: radial-gradient(circle at center, rgba(var(--color-interactive), 0.4) 0, rgba(var(--color-interactive), 0) 50%) no-repeat;
  width: 100%;
  height: 100%;
  top: -50%;
  left: -50%;
  opacity: 0.7;
}`, "",{"version":3,"sources":["webpack://./src/shared/background/background.scss"],"names":[],"mappings":"AAIA;EACC,sBAAA;EAGA,sBAAA;EACA,sBAAA;EACA,iCAAA;EACA,kBAAA;EACA,sBAAA;AAHD;;AAMA;EACC;IACC,uBAAA;EAHA;EAMD;IACC,yBAAA;EAJA;EAOD;IACC,yBAAA;EALA;AACF;AAQA;EACC;IACC,2BAAA;EANA;EASD;IACC,0BAAA;EAPA;EAUD;IACC,2BAAA;EARA;AACF;AAWA;EACC;IACC,4CAAA;EATA;EAYD;IACC,0CAAA;EAVA;EAaD;IACC,4CAAA;EAXA;AACF;AAcA;EACC,YAAA;EACA,aAAA;EACA,kBAAA;EACA,gBAAA;EACA,4FAAA;EACA,MAAA;EACA,OAAA;EACA,WAAA;EACA,2CAAA;AAZD;AAcC;EACC,eAAA;EACA,MAAA;EACA,OAAA;EACA,QAAA;EACA,SAAA;AAZF;AAeC;EACC,4BAAA;EACA,WAAA;EACA,YAAA;AAbF;AAeE;EAKC,kBAAA;EACA,0BAAA;AAjBH;AAoBE;EAEC,yBAAA;EACA,0BAAA;EACA,uCAAA;EACA,wCAAA;AAnBH;AAsBE;EACC,+GAAA;EACA,+BAAA;EACA,mDAAA;EACA,UAAA;AApBH;AAuBE;EACC,+GAAA;EACA,mCAAA;EACA,sDAAA;EACA,UAAA;AArBH;AAwBE;EACC,kBAAA;EACA,+GAAA;EACA,yBAAA;EACA,0BAAA;EACA,+CAAA;EACA,iDAAA;EACA,mCAAA;EACA,qDAAA;EACA,UAAA;AAtBH;AAyBE;EACC,yBAAA;EACA,0BAAA;EACA,uCAAA;EACA,yCAAA;EACA,+GAAA;EACA,mCAAA;EACA,qDAAA;EACA,YAAA;AAvBH;AA0BE;EACC,+GAAA;EACA,mCAAA;EACA,oCAAA;EACA,sCAAA;EACA,qCAAA;EACA,qDAAA;EACA,mDAAA;EACA,UAAA;AAxBH;AA2BE;EACC,qIAAA;EACA,WAAA;EACA,YAAA;EACA,SAAA;EACA,UAAA;EACA,YAAA;AAzBH","sourcesContent":["\n          @use \"@/styles/utils/mixins\" as mx;\n          @use \"@/styles/utils/breakpoints\" as bp;\n        \n:root {\r\n\t--color1: 20, 158, 246;\r\n\t--color2: 67, 179, 251;\r\n\t--color3: 11, 118, 187;\r\n\t--color2: 67, 179, 251;\r\n\t--color3: 11, 118, 187;\r\n\t--color-interactive: 20, 158, 246;\r\n\t--circle-size: 80%;\r\n\t--blending: hard-light;\r\n}\r\n\r\n@keyframes backgroundMoveInCircle {\r\n\t0% {\r\n\t\ttransform: rotate(0deg);\r\n\t}\r\n\r\n\t50% {\r\n\t\ttransform: rotate(180deg);\r\n\t}\r\n\r\n\t100% {\r\n\t\ttransform: rotate(360deg);\r\n\t}\r\n}\r\n\r\n@keyframes backgroundMoveVertical {\r\n\t0% {\r\n\t\ttransform: translateY(-50%);\r\n\t}\r\n\r\n\t50% {\r\n\t\ttransform: translateY(50%);\r\n\t}\r\n\r\n\t100% {\r\n\t\ttransform: translateY(-50%);\r\n\t}\r\n}\r\n\r\n@keyframes backgroundMoveHorizontal {\r\n\t0% {\r\n\t\ttransform: translateX(-50%) translateY(-10%);\r\n\t}\r\n\r\n\t50% {\r\n\t\ttransform: translateX(50%) translateY(10%);\r\n\t}\r\n\r\n\t100% {\r\n\t\ttransform: translateX(-50%) translateY(-10%);\r\n\t}\r\n}\r\n\r\n.background {\r\n\twidth: 100vw;\r\n\theight: 100vh;\r\n\tposition: absolute;\r\n\toverflow: hidden;\r\n\tbackground: linear-gradient(40deg, var(var(--e-grayscale-100)), var(var(--e-grayscale-100)));\r\n\ttop: 0;\r\n\tleft: 0;\r\n\tz-index: -1;\r\n\tanimation: eFade 800ms ease-in-out forwards;\r\n\r\n\t&-svg {\r\n\t\tposition: fixed;\r\n\t\ttop: 0;\r\n\t\tleft: 0;\r\n\t\twidth: 0;\r\n\t\theight: 0;\r\n\t}\r\n\r\n\t&-container {\r\n\t\tfilter: url(#goo) blur(40px);\r\n\t\twidth: 100%;\r\n\t\theight: 100%;\r\n\r\n\t\t&__blob-1,\r\n\t\t&__blob-2,\r\n\t\t&__blob-3,\r\n\t\t&__blob-4,\r\n\t\t&__blob-5 {\r\n\t\t\tposition: absolute;\r\n\t\t\tmix-blend-mode: hard-light;\r\n\t\t}\r\n\r\n\t\t&__blob-1,\r\n\t\t&__blob-2 {\r\n\t\t\twidth: var(--circle-size);\r\n\t\t\theight: var(--circle-size);\r\n\t\t\ttop: calc(50% - var(--circle-size) / 2);\r\n\t\t\tleft: calc(50% - var(--circle-size) / 2);\r\n\t\t}\r\n\r\n\t\t&__blob-1 {\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color1), 0.4) 0, rgba(var(--color1), 0) 50%) no-repeat;\r\n\t\t\ttransform-origin: center center;\r\n\t\t\tanimation: backgroundMoveVertical 30s ease infinite;\r\n\t\t\topacity: 1;\r\n\t\t}\r\n\r\n\t\t&__blob-2 {\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color2), 0.4) 0, rgba(var(--color2), 0) 50%) no-repeat;\r\n\t\t\ttransform-origin: calc(50% - 400px);\r\n\t\t\tanimation: backgroundMoveInCircle 20s reverse infinite;\r\n\t\t\topacity: 1;\r\n\t\t}\r\n\r\n\t\t&__blob-3 {\r\n\t\t\tposition: absolute;\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color3), 0.4) 0, rgba(var(--color3), 0) 50%) no-repeat;\r\n\t\t\twidth: var(--circle-size);\r\n\t\t\theight: var(--circle-size);\r\n\t\t\ttop: calc(50% - var(--circle-size) / 2 + 200px);\r\n\t\t\tright: calc(50% - var(--circle-size) / 2 - 500px);\r\n\t\t\ttransform-origin: calc(50% + 400px);\r\n\t\t\tanimation: backgroundMoveInCircle 40s linear infinite;\r\n\t\t\topacity: 1;\r\n\t\t}\r\n\r\n\t\t&__blob-4 {\r\n\t\t\twidth: var(--circle-size);\r\n\t\t\theight: var(--circle-size);\r\n\t\t\ttop: calc(50% - var(--circle-size) / 2);\r\n\t\t\tright: calc(50% - var(--circle-size) / 2);\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color4), 0.4) 0, rgba(var(--color4), 0) 50%) no-repeat;\r\n\t\t\ttransform-origin: calc(50% - 200px);\r\n\t\t\tanimation: backgroundMoveHorizontal 40s ease infinite;\r\n\t\t\topacity: 0.7;\r\n\t\t}\r\n\r\n\t\t&__blob-5 {\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color5), 0.4) 0, rgba(var(--color5), 0) 50%) no-repeat;\r\n\t\t\twidth: calc(var(--circle-size) * 2);\r\n\t\t\theight: calc(var(--circle-size) * 2);\r\n\t\t\tbottom: calc(50% - var(--circle-size));\r\n\t\t\tright: calc(50% - var(--circle-size));\r\n\t\t\ttransform-origin: calc(50% - 800px) calc(50% + 200px);\r\n\t\t\tanimation: backgroundMoveInCircle 20s ease infinite;\r\n\t\t\topacity: 1;\r\n\t\t}\r\n\r\n\t\t&__interactive {\r\n\t\t\tbackground: radial-gradient(circle at center, rgba(var(--color-interactive), 0.4) 0, rgba(var(--color-interactive), 0) 50%) no-repeat;\r\n\t\t\twidth: 100%;\r\n\t\t\theight: 100%;\r\n\t\t\ttop: -50%;\r\n\t\t\tleft: -50%;\r\n\t\t\topacity: 0.7;\r\n\t\t}\r\n\t}\r\n}\r\n"],"sourceRoot":""}]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/pages/dashboard/components/dashboard-card/dashboard-card.scss":
/*!***************************************************************************!*\
  !*** ./src/pages/dashboard/components/dashboard-card/dashboard-card.scss ***!
  \***************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard-card.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/components/dashboard-card/dashboard-card.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard-card.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/components/dashboard-card/dashboard-card.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard-card.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/components/dashboard-card/dashboard-card.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_card_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/pages/dashboard/dashboard.scss":
/*!********************************************!*\
  !*** ./src/pages/dashboard/dashboard.scss ***!
  \********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/dashboard.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/dashboard.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./dashboard.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/pages/dashboard/dashboard.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_dashboard_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./src/shared/background/background.scss":
/*!***********************************************!*\
  !*** ./src/shared/background/background.scss ***!
  \***********************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../../../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./background.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/shared/background/background.scss");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"], options);


if (true) {
  if (!_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }
  var p;
  for (p in a) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (a[p] !== b[p]) {
      return false;
    }
  }
  for (p in b) {
    if (isNamedExport && p === "default") {
      // eslint-disable-next-line no-continue
      continue;
    }
    if (!a[p]) {
      return false;
    }
  }
  return true;
};
    var isNamedExport = !_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;
    var oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

    module.hot.accept(
      /*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./background.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/shared/background/background.scss",
      __WEBPACK_OUTDATED_DEPENDENCIES__ => { /* harmony import */ _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../../../node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!../../../node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!../../../node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!../../../node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./background.scss */ "./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[2]!./node_modules/resolve-url-loader/index.js??ruleSet[1].rules[1].oneOf[7].use[3]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[1].oneOf[7].use[4]!./src/shared/background/background.scss");
(function () {
        if (!isEqualLocals(oldLocals, isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals, isNamedExport)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = isNamedExport ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__ : _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals;

              update(_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"]);
      })(__WEBPACK_OUTDATED_DEPENDENCIES__); }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}



       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_1_node_modules_postcss_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_2_node_modules_resolve_url_loader_index_js_ruleSet_1_rules_1_oneOf_7_use_3_node_modules_sass_loader_dist_cjs_js_ruleSet_1_rules_1_oneOf_7_use_4_background_scss__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ })

}]);
//# sourceMappingURL=src_pages_dashboard_dashboard_tsx.chunk.js.map